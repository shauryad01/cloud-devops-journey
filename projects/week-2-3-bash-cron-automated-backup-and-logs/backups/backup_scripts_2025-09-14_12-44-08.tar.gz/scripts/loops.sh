#!/bin/bash

<< task
arg 1 is folder name
arg 2 is start range
arg 3 is end range
task

for ((i=$2; i<=$3; i++))
do
	mkdir "$1$i"
done

