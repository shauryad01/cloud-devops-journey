#!/bin/bash

greet(){
	echo "Hello $1!"
}

sum(){
	sum=$(($1+$2))
	echo "Sum of $1 and $2 is: $sum"
}

greet "User"
sum 8 4
