#!/bin/bash

i=0
while [[ $i -le 8 ]];

do
	echo "lol"
	i=${i}+1
done
