#!/bin/bash

echo "arg 1: $1"
echo "arg 2: $2"
echo "All args: $@"
echo "No. of args: $#"

set -e  # exit


echo "Trying to list a valid directory..."
ls /home/ubuntu
echo "Exit code: $?"

echo "Trying to list a non-existent directory..."
ls /does/not/exist
echo "You will never see this line because set -e exits immediately"

