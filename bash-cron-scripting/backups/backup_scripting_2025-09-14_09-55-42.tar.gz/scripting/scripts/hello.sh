#!/bin/bash

echo "Hello"
echo "THis is my first bash script"
